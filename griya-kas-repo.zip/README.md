# Griya Kas — Sistem Akuntansi Persediaan & Pengeluaran Operasional Rumah Kost

Sistem pencatatan kas, persediaan (barang habis pakai kost), dan pengeluaran operasional rumah kost. Dibuat untuk Cahyaningrum.

🔗 Setelah GitHub Pages aktif, sistem bisa diakses di:
`https://cahyaningrum.github.io/NAMA-REPO-INI/frontend/index.html`

## Fitur
- **Dashboard** — saldo kas, pemasukan & pengeluaran bulan berjalan, nilai persediaan, peringatan stok menipis
- **Data Barang** — master persediaan (nama, kategori, satuan, stok, harga)
- **Kategori** — kategori barang & kategori pengeluaran operasional
- **Transaksi Persediaan** — catat barang masuk (pembelian, otomatis memotong kas) dan barang keluar (pemakaian)
- **Pengeluaran Operasional** — listrik, air, internet, gaji petugas, perbaikan, dll
- **Kas & Pemasukan** — seluruh arus kas otomatis terhitung, plus input pemasukan (mis. sewa kamar)
- **Laporan** — ringkasan + unduh CSV
- **Pengaturan** — nama & alamat kost, reset data

## Cara kerja & penyimpanan data
Aplikasi ini murni HTML/CSS/JavaScript (tanpa server/database eksternal). Semua data disimpan di **localStorage** milik browser yang mengakses halaman tersebut. Artinya:
- Data tersimpan otomatis setiap kali menambah/mengubah data.
- Data hanya tersimpan di browser & perangkat yang dipakai untuk mengakses — tidak otomatis sinkron antar perangkat/browser lain.
- Untuk memindahkan data ke perangkat lain, gunakan menu **Laporan → Unduh CSV**.

## Cara mempublikasikan (GitHub Pages)
1. Buat repository baru di akun GitHub **cahyaningrum**, beri nama bebas (misalnya `griya-kas`).
2. Upload seluruh isi folder ini (`frontend/index.html` dan `README.md`) ke repository tersebut — pertahankan struktur foldernya.
3. Buka **Settings → Pages** pada repo, pilih Branch `main`, folder `/ (root)`, lalu **Save**.
4. Tunggu 1–2 menit, link akan aktif di:
   `https://cahyaningrum.github.io/<nama-repo>/frontend/index.html`

## Struktur folder
```
frontend/
  index.html   ← seluruh aplikasi (HTML, CSS, JS jadi satu file)
README.md
```
